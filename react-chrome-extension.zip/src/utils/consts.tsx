export const TITLE_RANGE = [30, 60];
export const DESCRIPTION_RANGE = [100, 155];
export const HCOLOR = ["bg-blue-700", "bg-yellow-700", "bg-pink-700", "bg-green-700", "bg-lime-300", "bg-cyan-500"];
export const HBCOLOR = ["#1D4ED8", "#A16207", "#BE185D", "#10803D", "#BEF264", "#6B86D4"];